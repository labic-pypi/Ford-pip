import fordpip

fordpip.chebyshev(10);