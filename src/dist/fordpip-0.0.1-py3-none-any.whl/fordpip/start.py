import math

def chebyshev(x):
    y = math.acos(math.cos(x))
    print("Chebyshev:",y)
    return y